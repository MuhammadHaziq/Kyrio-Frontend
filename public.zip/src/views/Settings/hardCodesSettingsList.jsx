/*{" "}
<CListGroupItem
  onClick={() => setActiveTab(0)}
  action
  active={activeTab === 0}
  style={{ paddingLeft: "40px" }}
>
  General
</CListGroupItem>
<CListGroupItem
  onClick={() => setActiveTab(1)}
  action
  active={activeTab === 1}
  style={{ paddingLeft: "40px" }}
>
  Billing &amp; subscriptions
</CListGroupItem>
<CListGroupItem
  onClick={() => setActiveTab(2)}
  action
  active={activeTab === 2}
  style={{ paddingLeft: "40px" }}
>
  Payment types
</CListGroupItem>
<CListGroupItem
  onClick={() => setActiveTab(3)}
  action
  active={activeTab === 3}
  style={{ paddingLeft: "40px" }}
>
  Loyalty
</CListGroupItem>
<CListGroupItem
  onClick={() => setActiveTab(4)}
  action
  active={activeTab === 4}
  style={{ paddingLeft: "40px" }}
>
  Taxes
</CListGroupItem>
<CListGroupItem
  onClick={() => setActiveTab(5)}
  action
  active={activeTab === 5}
  style={{ paddingLeft: "40px" }}
>
  Receipt
</CListGroupItem>
<CListGroupItem
  onClick={() => setActiveTab(6)}
  action
  active={activeTab === 6}
  style={{ paddingLeft: "40px" }}
>
  Open tickets
</CListGroupItem>
<CListGroupItem
  onClick={() => setActiveTab(7)}
  action
  active={activeTab === 7}
  style={{ paddingLeft: "40px" }}
>
  Kitchen printers
</CListGroupItem>
<CListGroupItem
  onClick={() => setActiveTab(8)}
  action
  active={activeTab === 8}
  style={{ paddingLeft: "40px" }}
>
  Dining options
</CListGroupItem>
<CListGroupItem action active={false}>
  <h5>
    <MdStore style={{ fontSize: "30px" }} />
    <strong>&nbsp;Stores</strong>
    <br />
    <small>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Store
      &amp; POS settings
    </small>
  </h5>
</CListGroupItem>
<CListGroupItem
  onClick={() => setActiveTab(9)}
  action
  active={activeTab === 9}
  style={{ paddingLeft: "40px" }}
>
  Stores
</CListGroupItem>
<CListGroupItem
  onClick={() => setActiveTab(10)}
  action
  active={activeTab === 10}
  style={{ paddingLeft: "40px" }}
>
  POS devices
</CListGroupItem>{" "}
*/
